INSERT INTO orders(create_date_time,customer_id,restaurant_id,status,update_date_time) VALUES('2019-08-24 13:35:43.767000',1,1,'CREATED','2019-08-24 13:35:43.767000');
INSERT INTO orders(create_date_time,customer_id,restaurant_id,status,update_date_time) VALUES('2019-08-24 13:35:43.767000',2,2,'CREATED','2019-08-24 13:35:43.767000');
INSERT INTO orders(create_date_time,customer_id,restaurant_id,status,update_date_time) VALUES('2019-08-24 13:35:43.767000',3,3,'CREATED','2019-08-24 13:35:43.767000');
