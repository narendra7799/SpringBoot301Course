package com.eatza.customer.customerregistration;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.eatza.customer.customerregistration.repository.CustomerServiceRepository;
import com.eatza.customer.customerregistration.service.CustomerService;

@RunWith(SpringRunner.class)
public class CustomerServiceIntegrationTest {
	
	@InjectMocks
	CustomerService customerService;
	
	@Mock
	private CustomerServiceRepository customerServiceRepository;
	
	@Test
	public void createCustomer() {
		
	}

}
