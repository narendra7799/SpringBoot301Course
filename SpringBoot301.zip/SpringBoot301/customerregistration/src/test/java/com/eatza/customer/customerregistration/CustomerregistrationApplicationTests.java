package com.eatza.customer.customerregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerregistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
