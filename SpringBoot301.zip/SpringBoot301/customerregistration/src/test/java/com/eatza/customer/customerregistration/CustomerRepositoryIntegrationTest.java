package com.eatza.customer.customerregistration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.eatza.customer.customerregistration.entity.Customer;
import com.eatza.customer.customerregistration.repository.CustomerServiceRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
public class CustomerRepositoryIntegrationTest {

	@Autowired
    private CustomerServiceRepository employeeRepository;
	
	@Test
	public void testSaveRepo() {
		Customer customer = new Customer();
		customer.setActive(true);
		customer.setDefaultAddress("mettukuppam");
		customer.setDefaultPaymentMode("usd");
		customer.setFirstName("nachiyappan");
		customer.setLastName("sundaram");
		customer.setFoodPreference("chettinad");
		employeeRepository.save(customer);
		assertNotNull(customer.getCustomerId());
	}
	
	@Test
	public void testSearchRepo() {
		Customer customer = employeeRepository.findByFirstName("girish");
		assertNotNull(customer.getCustomerId());
		assertEquals("bharatwaj",customer.getLastName());
		assertNotNull(customer.isActive());
	}
	
	@Test
	public void testSearchAllRepo() {
		List<Customer> customerList = employeeRepository.findAll();
		assertEquals(3, customerList.size());
	}

}
