package com.eatza.customer.customerregistration.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.eatza.customer.customerregistration.domain.CommiqueForm;
import com.eatza.customer.customerregistration.domain.CustomerForm;
import com.eatza.customer.customerregistration.entity.Customer;
import com.eatza.customer.customerregistration.repository.CustomerServiceRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerServiceRepository customerServiceRepository;
	
	@Value("${notify.url}")
	private String notifyURL;
	
	@Autowired
	private RestTemplate restTemplate;

	public Customer createCustomer(CustomerForm customerForm) {
		try {
			Customer customer = new Customer();
			customer.setActive(true);
			customer.setFirstName(customerForm.getFirstName());
			customer.setLastName(customer.getLastName());
			customer.setDefaultAddress(customer.getDefaultAddress());
			customer.setDefaultPaymentMode(customerForm.getDefaultPaymentMode());
			customer.setFoodPreference(customerForm.getFoodPreference());
			CommiqueForm commiqueForm = new CommiqueForm("customer created with firstname", "from CustomerService");
			restTemplate.postForEntity(notifyURL, commiqueForm, String.class);
			customerServiceRepository.save(customer);
			return customer;
			
		} catch (Exception e) {
			e.printStackTrace();
			return new Customer();
		}

	}

	public List<Customer> getCustomer() {
		return customerServiceRepository.findAll();
	}
	
	public Customer getCustomer(String firstName) {
		return customerServiceRepository.findByFirstName(firstName);
	}
	
	public String deleteCustomer(String customerFirstName) {
		Customer customer = getCustomer(customerFirstName);
		if (customer!=null) {
			customer.setActive(false);
			customerServiceRepository.saveAndFlush(customer);
			return "success";
		}else {
			return "no such customer exists";
		}
	}

}
