insert into customer(customer_id,first_name, last_name, food_preference, default_address, default_payment_mode,active)
values( 1, 'girish','bharatwaj','veg','RT Nagar', 'PayPal', TRUE);

insert into customer(customer_id,first_name, last_name, food_preference, default_address, default_payment_mode,active)
values( 2, 'sap','waj','veg','Hebbal', 'Cash',TRUE);

insert into customer(customer_id,first_name, last_name, food_preference, default_address, default_payment_mode,active)
values( 3, 'jack','sparrow','non-veg','hollywood', 'Credit Card',TRUE);